if test -s test.jtl;
then
  echo 'found the file'
else
  echo 'found none'
fi
